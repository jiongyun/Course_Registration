
package oop_assignment1;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.Scanner;
import java.util.Collections;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean print=true;
		while (print=true){
		System.out.println("Choose one of the following options:");
		System.out.println("1) add a new contact");
		System.out.println("2) search for contact");
		System.out.println("3) display all contacts");
		System.out.println("4) quit");
		int choice;
		Scanner input =new Scanner(System.in);
		choice=input.nextInt();
		
		
		if (choice==1) {
			String n;
			String e;
			int p;
			int id=0;
			String note;
			
			System.out.println("name:");
			input.nextLine();
			n=input.nextLine();
			System.out.println("email:");
			e=input.next();
			System.out.println("phone:");
			p=input.nextInt();
			System.out.println("notes:");
			input.nextLine();
			note=input.nextLine();
			id=Contact.contacts.size()+1;
			Contact c=new Contact(id,n,e,p,note);
			Contact.contacts.add(c);
			System.out.println("Saved Succesfully...Press Enter to go back to the Main Window");
			 
	  
		}
		
		if(choice==2) {
			System.out.println("1) Search by Name");
			System.out.println("2) Search by Email");
			System.out.println("3) Search by Phone");
			System.out.println("Enter Your Choice: ");
			int choice_search;
			String n_search;
			String e_search;
			int p_search;
			choice_search=input.nextInt();
			if (choice_search==1) {
				System.out.println("Enter name: ");
				input.nextLine();
				n_search=input.nextLine();
				System.out.println("ID  |Name		|Email		|Phone		|Notes		");
				for(int i=0; i<Contact.contacts.size(); i++) {
					if(Contact.contacts.get(i).getName().contains(n_search)) {
						System.out.println(Contact.contacts.get(i));
					}
				}	
				System.out.println("Choose One of these options");
				System.out.println("1) To delete a contact");
				System.out.println("2) Back to Main Window");
				System.out.println("Enter Your Choice: ");
				int choice_delete=input.nextInt();
				if (choice_delete==1) {
					System.out.println("Enter the Contact Id: ");
					int choice_id=input.nextInt();
					for(int i=0; i<Contact.contacts.size(); i++) {
						if(Contact.contacts.get(i).getId()==choice_id) {
							Contact.contacts.remove(i);
							System.out.println("Deleted...press Enter to go back to Main Window");
						}
					}	
					
				}
				}
			if (choice_search==2) {
				System.out.println("Enter email: ");
				input.nextLine();
				e_search=input.nextLine();
				System.out.println("ID  |Name		|Email		|Phone		|Notes		");
				for(int i=0; i<Contact.contacts.size(); i++) {
					if(Contact.contacts.get(i).getEmail().equals(e_search)) {
						System.out.println(Contact.contacts.get(i));
					}
				}	
				System.out.println("Choose one of these options");
				System.out.println("1) To delete a contact");
				System.out.println("2) Back to Main Window");
				System.out.println("Enter Your Choice: ");
				int choice_delete=input.nextInt();
				if (choice_delete==1) {
					System.out.println("Enter the Contact Id: ");
					int choice_id=input.nextInt();
					for(int i=0; i<Contact.contacts.size(); i++) {
						if(Contact.contacts.get(i).getId()==choice_id) {
							Contact.contacts.remove(i);
							System.out.println("Deleted...press Enter to go back to Main Window");
						}
					}	
				}
				}
			if (choice_search==3) {
				System.out.println("Enter phone: ");
				p_search=input.nextInt();
				System.out.println("ID  |Name		|Email		|Phone		|Notes		");
				for(int i=0; i<Contact.contacts.size(); i++) {
					if(Contact.contacts.get(i).getPhone()==p_search) {
						System.out.println(Contact.contacts.get(i));
					}
				}
				System.out.println("Choose one of these options");
				System.out.println("1) To delete a contact");
				System.out.println("2) Back to Main Window");
				System.out.println("Enter Your Choice: ");
				int choice_delete=input.nextInt();
				if (choice_delete==1) {
					System.out.println("Enter the Contact Id: ");
					int choice_id=input.nextInt();
					for(int i=0; i<Contact.contacts.size(); i++) {
						if(Contact.contacts.get(i).getId()==choice_id) {
							Contact.contacts.remove(i);
							System.out.println("Deleted...press Enter to go back to Main Window");
						}
					}	
				}
				}
		}
		if(choice==3) {
			Collections.sort(Contact.contacts, new Comparator<Contact>() {
			    public int compare(Contact c1, Contact c2) {
			        return c1.getName().compareTo(c2.getName());
			    }
			});
			System.out.println("ID  |Name		|Email		|Phone		|Notes		");
			for(int i=0;i<Contact.contacts.size();i++) {
				System.out.println(Contact.contacts.get(i));
			}
		}
		if (choice==4) {
			print=false;
			break;
		}	

		}	
	}

}
